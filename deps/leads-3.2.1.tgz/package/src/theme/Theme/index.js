export const colors = {
  blueDarkerAccent: '#202365',
  blueDarker: '#00044c',
  blueDark: '#00419f',
  blue: '#0069ff',
  blueLight: '#4692ff',
  blueLighter: '#deecfd',

  greenDarker: '#003135',
  greenDark: '#00848e',
  green: '#47c1bf',
  greenLight: '#b7ecec',
  greenLighter: '#e0f5f5',

  redDarker: '#330101',
  redDark: '#bf0711',
  red: '#ed6347',
  redLight: '#feaf9a',
  redLighter: '#fbeae5',

  yellowDarker: '#573b00',
  yellowDark: '#9c6f19',
  yellow: '#eec200',
  yellowLight: '#ffea8a',
  yellowLighter: '#fcf1cd',

  purpleDarker: '#24235b',
  purpleDark: '#43418c',
  purple: '#5e5cc4',
  purpleLight: '#a09ee8',
  purpleLighter: '#dad9ff',

  greyDarker: '#4c515d',
  greyDark: '#797f89',
  grey: '#b1bacc',
  greyLight: '#e4e7ed',
  greyLighter: '#f2f4f7'
};
export const typography = {
  fontFamily: 'Akkurat',
  letterSpacing: 0,
  largeHeading: '30px',
  mediumHeading: '25px',
  pageHeading: '21px',
  heading: '17px',
  smallHeading: '15px',
  body: '15px',
  support: '13px',
  smallestHeader: '13px',
  inline: '14px'
};

export const typographyDefs = {
  largeDisplayHeading: {
    fontFamily: typography.fontFamily,
    fontSize: typography.largeHeading,
    fontWeight: 300,
    lineHeight: '48px',
    letterSpacing: typography.letterSpacing,
    color: colors.greyDarker
  },

  mediumDisplayHeading: {
    fontFamily: typography.fontFamily,
    fontSize: typography.mediumHeading,
    fontWeight: 400,
    lineHeight: '36px',
    letterSpacing: typography.letterSpacing,
    color: colors.greyDarker
  },

  inPageHeading: {
    fontFamily: typography.fontFamily,
    fontSize: typography.pageHeading,
    fontWeight: 400,
    lineHeight: '24px',
    letterSpacing: typography.letterSpacing,
    color: colors.greyDarker
  },

  headingDefault: {
    fontFamily: typography.fontFamily,
    fontSize: typography.heading,
    fontWeight: 400,
    lineHeight: '24px',
    letterSpacing: typography.letterSpacing,
    color: colors.greyDarker
  },

  bodyHeading: {
    fontFamily: typography.fontFamily,
    fontSize: typography.smallHeading,
    fontWeight: 700,
    lineHeight: '24px',
    letterSpacing: typography.letterSpacing,
    color: colors.greyDarker
  },

  bodyDefault: {
    fontFamily: typography.fontFamily,
    fontSize: typography.body,
    fontWeight: 400,
    lineHeight: '24px',
    letterSpacing: typography.letterSpacing,
    color: colors.greyDarker
  },

  supportContent: {
    fontFamily: typography.fontFamily,
    fontSize: typography.support,
    fontWeight: 400,
    lineHeight: '18px',
    letterSpacing: typography.letterSpacing,
    color: colors.greyDark
  },

  tableHeader: {
    fontFamily: typography.fontFamily,
    fontSize: typography.smallestHeader,
    fontWeight: 400,
    lineHeight: '18px',
    letterSpacing: typography.letterSpacing,
    color: colors.greyDark
  },

  inlineLink: {
    fontFamily: typography.fontFamily,
    fontSize: typography.inline,
    fontWeight: 400,
    lineHeight: '24px',
    letterSpacing: typography.letterSpacing,
    color: colors.blue
  }
};
export const shadows = {
  l1: '0 0 2px 0 rgba(0, 0, 0, 0.25), 0 1px 3px 0 rgba(0, 0, 0, 0.2)',
  l2: '0 0 6px 0 rgba(0, 0, 0, 0.25), 0 3px 6px 0 rgba(0, 0, 0, 0.2)',
  l3: '0 0 6px 0 rgba(0, 0, 0, 0.25), 0 8px 10px 0 rgba(0, 0, 0, 0.25)',
  l4: '0 0 10px 0 rgba(0, 0, 0, 0.25), 0 12px 18px 0 rgba(0, 0, 0, 0.3)',
  l5: '0 0 12px 0 rgba(0, 0, 0, 0.25), 0 16px 18px 0 rgba(0, 0, 0, 0.35)'
};

export default {
  colors,
  typography,
  typographyDefs,
  shadows
};
