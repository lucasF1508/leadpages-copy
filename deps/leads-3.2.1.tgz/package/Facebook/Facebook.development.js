'use strict';

Object.defineProperty(exports, '__esModule', { value: true });

function _interopDefault (ex) { return (ex && (typeof ex === 'object') && 'default' in ex) ? ex['default'] : ex; }

var camelCase = _interopDefault(require('lodash/camelCase'));
var React = _interopDefault(require('react'));
var PropTypes = _interopDefault(require('prop-types'));
var classNames = _interopDefault(require('classnames'));
var Indicator = _interopDefault(require('../Indicator'));

function _defineProperty(obj, key, value) {
  if (key in obj) {
    Object.defineProperty(obj, key, {
      value: value,
      enumerable: true,
      configurable: true,
      writable: true
    });
  } else {
    obj[key] = value;
  }

  return obj;
}

var defineProperty = _defineProperty;

function styleInject(css, ref) {
  if ( ref === void 0 ) ref = {};
  var insertAt = ref.insertAt;

  if (!css || typeof document === 'undefined') { return; }

  var head = document.head || document.getElementsByTagName('head')[0];
  var style = document.createElement('style');
  style.type = 'text/css';

  if (insertAt === 'top') {
    if (head.firstChild) {
      head.insertBefore(style, head.firstChild);
    } else {
      head.appendChild(style);
    }
  } else {
    head.appendChild(style);
  }

  if (style.styleSheet) {
    style.styleSheet.cssText = css;
  } else {
    style.appendChild(document.createTextNode(css));
  }
}

var css = ":root {\n  /* colors */\n\n  /* blue */ /* Builder side nav */\n\n  /* green */\n\n  /* red */\n\n  /* yellow */\n\n  /* purple */\n\n  /* grey */\n\n  /* shadows */\n\n  /* typography */\n}\n\n.FacebookTrafficSource_container__2tGkI {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n}\n\n.FacebookTrafficSource_trafficSourceBase__1B5T0 {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n\n  -webkit-box-align: center;\n\n      -ms-flex-align: center;\n\n          align-items: center;\n\n  width: 430px;\n  height: 54px;\n\n  cursor: default;\n  -webkit-transition: -webkit-box-shadow 0.3s ease;\n  transition: -webkit-box-shadow 0.3s ease;\n  transition: box-shadow 0.3s ease;\n  transition: box-shadow 0.3s ease, -webkit-box-shadow 0.3s ease;\n\n  opacity: 0.5;\n\n  border: 1px dashed #b1bacc;\n  border-radius: 3px\n}\n\n.FacebookTrafficSource_trafficSourceBase__1B5T0.FacebookTrafficSource_populated__GbhlC {\n  border: 1px solid #b1bacc;\n  background-color: #ffffff;\n}\n\n.FacebookTrafficSource_trafficSourceBase__1B5T0.FacebookTrafficSource_populated__GbhlC:hover {\n  -webkit-transition: -webkit-box-shadow 0.3s ease;\n  transition: -webkit-box-shadow 0.3s ease;\n  transition: box-shadow 0.3s ease;\n  transition: box-shadow 0.3s ease, -webkit-box-shadow 0.3s ease;\n  border: 1px solid #b1bacc;\n  -webkit-box-shadow: 0 0 6px 0 rgba(0, 0, 0, .25), 0 3px 6px 0 rgba(0, 0, 0, .2);\n          box-shadow: 0 0 6px 0 rgba(0, 0, 0, .25), 0 3px 6px 0 rgba(0, 0, 0, .2);\n}\n\n.FacebookTrafficSource_trafficSourceBase__1B5T0.FacebookTrafficSource_tsEnabled__3pNzI {\n  cursor: pointer;\n  opacity: 1;\n}\n\n.FacebookTrafficSource_trafficSourceBase__1B5T0.FacebookTrafficSource_tsEnabled__3pNzI:hover {\n  border: 1px dashed #00419f;\n}\n\n.FacebookTrafficSource_trafficSourceIcon__xUe3F {\n  padding: 0 8px;\n}\n\n.FacebookTrafficSource_trafficSourceContent__3s5VR {\n  width: 87%\n}\n\n.FacebookTrafficSource_trafficSourceContent__3s5VR .FacebookTrafficSource_title__3I_dG {\n  font-family: 'Akkurat';\n  font-size: 15px;\n  font-weight: 400;\n  line-height: 24px;\n  letter-spacing: 0;\n  color: #4c515d;\n  overflow: hidden;\n  -webkit-box-flex: 1;\n      -ms-flex: 1;\n          flex: 1;\n  min-width: 0;\n  white-space: nowrap;\n  text-overflow: ellipsis;\n}\n\n.FacebookTrafficSource_trafficSourceContent__3s5VR .FacebookTrafficSource_analytics__2Ro0y {\n  font-family: 'Akkurat';\n  font-size: 13px;\n  font-weight: 400;\n  line-height: 18px;\n  letter-spacing: 0;\n  color: #797f89;\n  text-transform: capitalize;\n}\n\n.FacebookTrafficSource_analyticsDisplay__3UD5v {\n  display: -webkit-box;\n  display: -ms-flexbox;\n  display: flex;\n  -webkit-box-align: center;\n      -ms-flex-align: center;\n          align-items: center;\n}\n\n.FacebookTrafficSource_indicator__3Sk-j > div {\n  display: block;\n}\n";
var styles = {"container":"FacebookTrafficSource_container__2tGkI","trafficSourceBase":"FacebookTrafficSource_trafficSourceBase__1B5T0","populated":"FacebookTrafficSource_populated__GbhlC","tsEnabled":"FacebookTrafficSource_tsEnabled__3pNzI","trafficSourceIcon":"FacebookTrafficSource_trafficSourceIcon__xUe3F","trafficSourceContent":"FacebookTrafficSource_trafficSourceContent__3s5VR","title":"FacebookTrafficSource_title__3I_dG","analytics":"FacebookTrafficSource_analytics__2Ro0y","analyticsDisplay":"FacebookTrafficSource_analyticsDisplay__3UD5v","indicator":"FacebookTrafficSource_indicator__3Sk-j"};
styleInject(css);

var css$1 = ":root {\n  /* colors */\n\n  /* blue */ /* Builder side nav */\n\n  /* green */\n\n  /* red */\n\n  /* yellow */\n\n  /* purple */\n\n  /* grey */\n\n  /* shadows */\n\n  /* typography */\n}\n\n.FacebookIcon_thumbnail__1Brby {\n  border-radius: 3px;\n\n  -o-object-fit: cover;\n\n     object-fit: cover;\n}\n\n.FacebookIcon_hasImage__1Sm6y {\n  border: 1px solid #b1bacc;\n}\n";
var styles$1 = {"thumbnail":"FacebookIcon_thumbnail__1Brby","hasImage":"FacebookIcon_hasImage__1Sm6y"};
styleInject(css$1);

var FacebookIcon = function FacebookIcon(_ref) {
  var imgSrc = _ref.imgSrc;
  return React.createElement("div", {
    style: {
      position: 'relative',
      height: '36px'
    }
  }, !imgSrc && React.createElement("svg", {
    width: "36px",
    height: "36px",
    viewBox: "0 0 24 24",
    version: "1.1",
    xmlns: "http://www.w3.org/2000/svg"
  }, React.createElement("g", {
    id: "Symbols",
    stroke: "none",
    strokeWidth: "1",
    fill: "none",
    fillRule: "evenodd"
  }, React.createElement("g", {
    id: "Facebook-Ad",
    transform: "translate(0.000000, -2.000000)"
  }, React.createElement("g", {
    id: "facebook_integration"
  }, React.createElement("g", {
    transform: "translate(0.000000, 2.000000)"
  }, React.createElement("rect", {
    id: "Rectangle-1",
    fill: "#4477BD",
    x: "0",
    y: "0",
    width: "24",
    height: "24",
    rx: "3"
  }), React.createElement("path", {
    d: "M15.5341797,6.71386719 L15.5341797,8.56738281 L14.4296875,8.56738281 C14.2265615,8.56738281 14.0572923,8.58854146 13.921875,8.63085938 C13.7864577,8.67317729 13.6848962,8.73665322 13.6171875,8.82128906 C13.5494788,8.9059249 13.4965822,9.01171812 13.4584961,9.13867188 C13.42041,9.26562563 13.4013672,9.4095044 13.4013672,9.5703125 L13.4013672,10.9033203 L15.4580078,10.9033203 L15.1914062,12.9726562 L13.4013672,12.9726562 L13.4013672,18.2919922 L11.2558594,18.2919922 L11.2558594,12.9726562 L9.46582031,12.9726562 L9.46582031,10.9033203 L11.2558594,10.9033203 L11.2558594,9.37988281 C11.2558594,8.93977645 11.3172194,8.55045742 11.4399414,8.21191406 C11.5626634,7.8733707 11.7467436,7.58561316 11.9921875,7.34863281 C12.2291679,7.11165246 12.5105778,6.931804 12.8364258,6.80908203 C13.1622738,6.68636006 13.5283183,6.625 13.9345703,6.625 C14.2731137,6.625 14.5756823,6.63346346 14.8422852,6.65039062 C15.1088881,6.66731779 15.3395173,6.68847644 15.5341797,6.71386719 Z",
    id: "facebook",
    fill: "#FFFFFF"
  })))))), imgSrc && React.createElement("img", {
    alt: "facebook ad thumbnail",
    className: classNames(styles$1.thumbnail, defineProperty({}, "".concat(styles$1.hasImage), !!imgSrc)),
    height: "36px",
    width: "36px",
    src: imgSrc
  }));
};

FacebookIcon.propTypes = {
  imgSrc: PropTypes.string
};
FacebookIcon.defaultProps = {
  imgSrc: null,
  showStatus: false,
  status: ''
};

var facebookStatuses = {
  active: 'success',
  scheduled: 'info',
  inactive: 'info',
  notDelivering: 'info',
  completed: 'info',
  deleted: 'info',
  inReview: 'info',
  limited: 'info',
  notApproved: 'error'
};

var determineStatus = function determineStatus(status) {
  var camelStatus = camelCase(status);
  var indicatorStatus = facebookStatuses[camelStatus];
  if (!indicatorStatus) return 'info';
  return indicatorStatus;
};

var FacebookTrafficSource = function FacebookTrafficSource(_ref) {
  var _classNames;

  var className = _ref.className,
      enabled = _ref.enabled,
      ad = _ref.ad,
      adStatus = _ref.adStatus,
      analyticsDisplay = _ref.analyticsDisplay,
      onClick = _ref.onClick;
  var _ad$name = ad.name,
      name = _ad$name === void 0 ? '' : _ad$name,
      _ad$id = ad.id,
      id = _ad$id === void 0 ? null : _ad$id,
      _ad$imgSrc = ad.imgSrc,
      imgSrc = _ad$imgSrc === void 0 ? null : _ad$imgSrc;
  return React.createElement("div", {
    className: styles.container
  }, React.createElement("div", {
    tabIndex: enabled ? 0 : undefined,
    role: enabled ? 0 : undefined,
    onClick: enabled ? onClick : undefined,
    className: classNames(className, styles.trafficSourceBase, (_classNames = {}, defineProperty(_classNames, "".concat(styles.tsEnabled), enabled), defineProperty(_classNames, "".concat(styles.populated), !!id), _classNames))
  }, React.createElement("div", {
    className: classNames(styles.trafficSourceIcon)
  }, React.createElement(FacebookIcon, {
    imgSrc: imgSrc
  })), React.createElement("div", {
    className: classNames(styles.trafficSourceContent)
  }, React.createElement("div", {
    className: styles.title
  }, id ? name : 'Create a Facebook Ad'), !!adStatus && React.createElement("div", {
    className: styles.analyticsDisplay
  }, React.createElement("div", {
    className: styles.indicator
  }, React.createElement(Indicator, {
    status: determineStatus(adStatus)
  })), React.createElement("div", {
    className: styles.analytics
  }, analyticsDisplay)))));
};

FacebookTrafficSource.propTypes = {
  ad: PropTypes.shape({}),
  adStatus: PropTypes.string,
  analyticsDisplay: PropTypes.string,
  enabled: PropTypes.bool,
  onClick: PropTypes.func,
  className: PropTypes.string
};
FacebookTrafficSource.defaultProps = {
  ad: {},
  adStatus: '',
  analyticsDisplay: '',
  enabled: false,
  onClick: function onClick() {},
  className: ''
};

exports.FacebookTrafficSource = FacebookTrafficSource;
exports.default = FacebookTrafficSource;
