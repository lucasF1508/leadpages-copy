'use strict';

if (process.env.NODE_ENV === 'production') {
  module.exports = require('./ConfirmModal.production.min.js');
} else {
  module.exports = require('./ConfirmModal.development.js');
}
      