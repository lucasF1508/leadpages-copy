# @lp/slugify

A JavaScript library for generating unicode-friendly [IRI][IRI] slugs.


## Behavior

1.  Unicode [NFKC][NFKC] rules are applied to the string.  This basically applies a compatibility translation, and then a canonical translation.  Example: `ﬁ` can be translated into `fi`.
1. Downcasing of text.
1. Replace spaces with `-`.
1. Select only alphanumeric characters, `-`, `_`, or `~`.  Omit everything else.
1. Merge repeated `-` into one.
2. Trim trailing and leading `-`.


## Usage

```javascript
import slugify from "@lp/slugify";
slugify("你好... or nǐ hǎo!"); // 你好-or-nǐ-hǎo
```

[NFKC]: http://unicode.org/reports/tr15/#Compatibility_Composite_Figure
[IRI]: https://en.wikipedia.org/wiki/Internationalized_Resource_Identifier