import slugify from "..";

describe("slugify", () => {
  it("should output proper slugs", () => {
    const testSlugs = {
      "Bän...g (bang)": "bäng-bang",
      "multiple  spaces": "multiple-spaces",
      "with *asteriks*": "with-asteriks",
      "i_am_allow~--ed": "i_am_allow~-ed",
      an_underscore: "an_underscore",
      "a-dash": "a-dash",
      "1234_56": "1234_56",
      "astral non-alphanumeric 😊": "astral-non-alphanumeric",
      "astral alphanumerics 𝚮ℋ": "astral-alphanumerics-ηh",
      "  leading and trailing whitespace  ": "leading-and-trailing-whitespace",
      影師: "影師",
      "This & that": "this-that",
      "Hellö Wörld хелло ворлд": "hellö-wörld-хелло-ворлд",
      "emoji-💩": "emoji",
      "𓃺": "", // Egyptian Hieroglyph
    };
    Object.entries(testSlugs).forEach(([input, output]) => {
      expect(slugify(input)).toEqual(output);
    });
  });
});
