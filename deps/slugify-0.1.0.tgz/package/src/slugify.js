import { alphanumeric } from "./unicode";

const SEPARATOR = "-";
const SEPARATORS = `_~${SEPARATOR}`; // Hyphen must be last for regex character class.
const RE_VALID = new RegExp(`(${alphanumeric}|[${SEPARATORS}])+`, "g");
const RE_MULTI_SEPARATOR = new RegExp(`${SEPARATOR}{2,}`, "g");
const RE_TRIM = new RegExp(`^[${SEPARATORS}]|[${SEPARATORS}]+$`, "g");

export const slugify = text => {
  const matches = text
    .normalize("NFKC")
    .toLowerCase()
    .replace(/\s+/g, SEPARATOR)
    .match(RE_VALID);
  if (matches === null) {
    return "";
  }
  const slug = matches
    .join("")
    .replace(RE_MULTI_SEPARATOR, SEPARATOR)
    .replace(RE_TRIM, "");
  return slug;
};

export default slugify;
