#!/usr/bin/env node

const fs = require("fs");

const maxSize = 12 * 1024;

var bundleStats = fs.statSync(`${__dirname}/../dist/main.js`);
var sizeBytes = bundleStats.size;

if (sizeBytes > maxSize) {
  console.error(`ERROR: Bundle size exceeds ${maxSize} bytes: ${sizeBytes}`);
  process.exit(1);
} else {
  console.info(`Bundle size OK: ${sizeBytes}`);
}
