const path = require("path");
const BundleAnalyzerPlugin = require("webpack-bundle-analyzer").BundleAnalyzerPlugin;

module.exports = {
  output: {
    library: {
      commonjs: "@lp/slugify",
      amd: "Slugify",
      root: "Slugify",
    },
    libraryTarget: "umd",
    globalObject: "(typeof self !== 'undefined' ? self : typeof global !== 'undefined' ? global : this)",
  },
  module: {
    rules: [
      {
        test: /\.(js|jsx)$/,
        include: [path.resolve(__dirname, "src")],
        use: {
          loader: "babel-loader",
        },
      },
    ],
  },
  plugins: (process.env.ANALYZE_BUNDLE && [new BundleAnalyzerPlugin()]) || [],
};
