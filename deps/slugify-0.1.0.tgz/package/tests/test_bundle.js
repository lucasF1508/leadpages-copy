// Ensure the bundled asset can be imported with node.
// https://github.com/webpack/webpack/issues/6522
var slugify = require("../dist/main.js");
var assert = require("assert");

// And let's just make sure it functions, and is the default export.
assert.strictEqual(slugify.default("-test-"), "test");
