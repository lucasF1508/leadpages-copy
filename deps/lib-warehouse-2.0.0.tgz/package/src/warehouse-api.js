import Chevron from '@lp/chevron';
import { Config } from '@lp/config';
import Observations from '@lp/observations-js';
import { name as packageName, version } from '../package.json';

export const CRATES_PATH = '/v1/crates';
export const BOTTLES_PATH = '/v1/bottles';

export const JSON_HEADERS = {
  'Content-Type': 'application/json',
};

export const idFmt = '<id>';

let instance = null;

export class WarehouseApi {
  constructor(baseUrl) {
    this.baseUrl = baseUrl || `${Config.getInstance().get('API_HOST')}/warehouse`;
    this.chevron = Chevron.getInstance();
    this.observations = new Observations({
      origin: packageName,
      version,
    });
    return this;
  }

  request(opts) {
    return this.chevron.http({
      url: opts.url,
      method: opts.method || 'GET',
      headers: opts.headers || JSON_HEADERS,
      params: opts.params,
      body: opts.body,
    });
  }

  handleHttpError(_err, metricTags) {
    this.observations.record('counter', 'http_request_failures_total', '1', metricTags);
  }

  requestWithMetrics(opts, metricTags) {
    /* eslint-disable no-param-reassign */
    // Record the method and status implicitly.
    metricTags.method = opts.method || 'GET';
    return this.request(opts)
      .then((res) => {
        metricTags.code = '';
        if (res && res._status && res._status.code) {
          metricTags.code = res._status.code.toString();
        }
        this.observations.recordRequest('http_response', opts.url, metricTags);
        return res;
      })
      .catch((err) => {
        this.handleHttpError(err, metricTags);
        throw err;
      });
  }

  getCrates(params) {
    return this.requestWithMetrics(
      { url: `${this.baseUrl}${CRATES_PATH}`, params },
      { path: CRATES_PATH },
    );
  }

  getCrateById(id) {
    return this.requestWithMetrics(
      { url: `${this.baseUrl}${CRATES_PATH}/${id}` },
      { path: `${CRATES_PATH}/${idFmt}` },
    );
  }

  updateCrate(id, body) {
    return this.requestWithMetrics(
      { url: `${this.baseUrl}${CRATES_PATH}/${id}`, body, method: 'PUT' },
      { path: `${CRATES_PATH}/${idFmt}` },
    );
  }

  deleteCrate(id) {
    return this.requestWithMetrics(
      { url: `${this.baseUrl}${CRATES_PATH}/${id}`, method: 'DELETE' },
      { path: `${CRATES_PATH}/${idFmt}` },
    );
  }

  getBottles(params) {
    return this.requestWithMetrics(
      { url: `${this.baseUrl}${BOTTLES_PATH}`, params },
      { path: BOTTLES_PATH },
    );
  }

  getBottleById(id) {
    return this.requestWithMetrics(
      { url: `${this.baseUrl}${BOTTLES_PATH}/${id}` },
      { path: `${BOTTLES_PATH}/${idFmt}` },
    );
  }

  updateBottle(id, body) {
    return this.requestWithMetrics(
      { url: `${this.baseUrl}${BOTTLES_PATH}/${id}`, body, method: 'PUT' },
      { path: `${BOTTLES_PATH}/${idFmt}` },
    );
  }

  deleteBottle(id) {
    return this.requestWithMetrics(
      { url: `${this.baseUrl}${BOTTLES_PATH}/${id}`, method: 'DELETE' },
      { path: `${BOTTLES_PATH}/${idFmt}` },
    );
  }

  getBottlesByCrate(id) {
    return this.requestWithMetrics(
      { url: `${this.baseUrl}${CRATES_PATH}/${id}/bottles` },
      { path: `${CRATES_PATH}/${idFmt}/bottles` },
    );
  }

  createBottleForCrate(id, body) {
    return this.requestWithMetrics(
      { url: `${this.baseUrl}${CRATES_PATH}/${id}/bottles`, method: 'POST', body },
      { path: `${CRATES_PATH}/${idFmt}/bottles` },
    );
  }
}

function getInstance(baseUrl) {
  if (!instance) {
    instance = new WarehouseApi(baseUrl);
  }
  return instance;
}

WarehouseApi.getInstance = getInstance;

export default WarehouseApi;
