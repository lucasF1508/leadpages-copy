import { Config } from '@lp/config';
import Chevron from '@lp/chevron';
import Observations from '@lp/observations-js';

import { WarehouseApi, CRATES_PATH, BOTTLES_PATH, JSON_HEADERS, idFmt } from '../warehouse-api';
import packageJson from '../../package.json';

const config = Config.getInstance();

const API_HOST = config.get('API_HOST');
const BASE_URL = `${API_HOST}/warehouse`;
const CRATES_URL = `${BASE_URL}${CRATES_PATH}`;
const BOTTLES_URL = `${BASE_URL}${BOTTLES_PATH}`;

describe('WarehouseApi', () => {
  let chevronMock;
  let api; // The WarehouseApi instance.

  beforeEach(() => {
    chevronMock = Chevron.getInstance();
    chevronMock.http = jest.fn().mockResolvedValue({});
    api = WarehouseApi.getInstance();
  });

  afterEach(() => {
    chevronMock.http.mockClear();
    api.observations.recordRequest.mockClear();
  });

  it('has constants correctly populated', () => {
    expect(API_HOST).toEqual('https://api.lp');
    expect(CRATES_PATH).toEqual('/v1/crates');
    expect(BOTTLES_PATH).toEqual('/v1/bottles');
  });

  describe('constructor', () => {
    it('created an observations instance', () => {
      expect(packageJson.name).toEqual(expect.any(String));
      expect(packageJson.version).toEqual(expect.any(String));
      expect(Observations).toHaveBeenCalledWith({
        origin: packageJson.name,
        version: packageJson.version,
      });
    });

    it('has proper objects on the instance', () => {
      expect(api.baseUrl).toEqual(`${API_HOST}/warehouse`);
      expect(api.chevron).toBe(chevronMock);
      expect(api.observations).toEqual(expect.anything());
    });

    it('can override baseUrl from config', () => {
      const baseUrl = 'http://override';
      api = new WarehouseApi(baseUrl);
      expect(api.baseUrl).toEqual(baseUrl);
    });

    it('uses the singleton instance on repeat getInstance calls', () => {
      const newBaseUrl = 'http://override';
      const currentBaseUrl = api.baseUrl;
      expect(newBaseUrl).not.toEqual(currentBaseUrl);
      api = WarehouseApi.getInstance(newBaseUrl);
      expect(api.baseUrl).toEqual(currentBaseUrl);
    });
  });

  describe('handleHttpError', () => {
    it('should record a metric', () => {
      api.handleHttpError('anError', { key: 'value' });
      expect(api.observations.record).toHaveBeenCalledWith(
        'counter',
        'http_request_failures_total',
        '1',
        { key: 'value' },
      );
    });
  });

  describe('requestWithMetrics', () => {
    it('should call handleHttpError if a request fails', async () => {
      // With a mocked promise error
      chevronMock.http.mockRejectedValue('anError');
      // And a mocked error handler
      api.handleHttpError = jest.fn();

      await expect(api.getCrates()).rejects.toEqual('anError');
      expect(api.handleHttpError).toBeCalledWith('anError', {
        method: 'GET',
        path: CRATES_PATH,
      });
    });
  });

  describe('getCrates', () => {
    it('calls chevron with the url', async () => {
      await api.getCrates();

      expect(chevronMock.http).toHaveBeenCalledWith({
        url: CRATES_URL,
        method: 'GET',
        headers: JSON_HEADERS,
      });
    });

    it('records the request', async () => {
      await api.getCrates();
      expect(api.observations.recordRequest).toHaveBeenCalledWith('http_response', CRATES_URL, {
        method: 'GET',
        path: CRATES_PATH,
        code: '',
      });
    });
  });

  describe('getCrateById', () => {
    it('calls chevron with the url', async () => {
      await api.getCrateById('id-1');

      expect(chevronMock.http).toHaveBeenCalledWith({
        url: `${CRATES_URL}/id-1`,
        method: 'GET',
        headers: JSON_HEADERS,
      });
    });

    it('records the request', async () => {
      await api.getCrateById('id-1');
      expect(api.observations.recordRequest).toHaveBeenCalledWith(
        'http_response',
        `${CRATES_URL}/id-1`,
        {
          method: 'GET',
          path: `${CRATES_PATH}/${idFmt}`,
          code: '',
        },
      );
    });
  });

  describe('updateCrate', () => {
    const body = {
      bottles: { contents: {} },
    };
    it('calls chevron with the url', async () => {
      await api.updateCrate('id-1', body);

      expect(chevronMock.http).toHaveBeenCalledWith({
        url: `${CRATES_URL}/id-1`,
        method: 'PUT',
        headers: JSON_HEADERS,
        body,
      });
    });

    it('records the request', async () => {
      await api.updateCrate('id-1', body);
      expect(api.observations.recordRequest).toHaveBeenCalledWith(
        'http_response',
        `${CRATES_URL}/id-1`,
        {
          method: 'PUT',
          path: `${CRATES_PATH}/${idFmt}`,
          code: '',
        },
      );
    });
  });

  describe('deleteCrate', () => {
    it('calls chevron with the url', async () => {
      await api.deleteCrate('id-1');

      expect(chevronMock.http).toHaveBeenCalledWith({
        url: `${CRATES_URL}/id-1`,
        method: 'DELETE',
        headers: JSON_HEADERS,
      });
    });

    it('records the request', async () => {
      await api.deleteCrate('id-1');
      expect(api.observations.recordRequest).toHaveBeenCalledWith(
        'http_response',
        `${CRATES_URL}/id-1`,
        {
          method: 'DELETE',
          path: `${CRATES_PATH}/${idFmt}`,
          code: '',
        },
      );
    });
  });

  describe('getBottles', () => {
    it('calls chevron with the url', async () => {
      await api.getBottles();

      expect(chevronMock.http).toHaveBeenCalledWith({
        url: BOTTLES_URL,
        method: 'GET',
        headers: JSON_HEADERS,
      });
    });

    it('records the request', async () => {
      await api.getBottles();
      expect(api.observations.recordRequest).toHaveBeenCalledWith('http_response', BOTTLES_URL, {
        method: 'GET',
        path: BOTTLES_PATH,
        code: '',
      });
    });
  });

  describe('getBottleById', () => {
    it('calls chevron with the url', async () => {
      await api.getBottleById('id-1');

      expect(chevronMock.http).toHaveBeenCalledWith({
        url: `${BOTTLES_URL}/id-1`,
        method: 'GET',
        headers: JSON_HEADERS,
      });
    });

    it('records the request', async () => {
      await api.getBottleById('id-1');
      expect(api.observations.recordRequest).toHaveBeenCalledWith(
        'http_response',
        `${BOTTLES_URL}/id-1`,
        {
          method: 'GET',
          path: `${BOTTLES_PATH}/${idFmt}`,
          code: '',
        },
      );
    });
  });

  describe('updateBottle', () => {
    const body = {
      contents: {},
    };
    it('calls chevron with the url', async () => {
      await api.updateBottle('id-1', body);

      expect(chevronMock.http).toHaveBeenCalledWith({
        url: `${BOTTLES_URL}/id-1`,
        method: 'PUT',
        headers: JSON_HEADERS,
        body,
      });
    });

    it('records the request', async () => {
      await api.updateBottle('id-1', body);
      expect(api.observations.recordRequest).toHaveBeenCalledWith(
        'http_response',
        `${BOTTLES_URL}/id-1`,
        {
          method: 'PUT',
          path: `${BOTTLES_PATH}/${idFmt}`,
          code: '',
        },
      );
    });
  });

  describe('deleteBottle', () => {
    it('calls chevron with the url', async () => {
      await api.deleteBottle('id-1');

      expect(chevronMock.http).toHaveBeenCalledWith({
        url: `${BOTTLES_URL}/id-1`,
        method: 'DELETE',
        headers: JSON_HEADERS,
      });
    });

    it('records the request', async () => {
      await api.deleteBottle('id-1');
      expect(api.observations.recordRequest).toHaveBeenCalledWith(
        'http_response',
        `${BOTTLES_URL}/id-1`,
        {
          method: 'DELETE',
          path: `${BOTTLES_PATH}/${idFmt}`,
          code: '',
        },
      );
    });
  });

  describe('getBottlesByCrate', () => {
    it('calls chevron with the url', async () => {
      await api.getBottlesByCrate('id-1');

      expect(chevronMock.http).toHaveBeenCalledWith({
        url: `${CRATES_URL}/id-1/bottles`,
        method: 'GET',
        headers: JSON_HEADERS,
      });
    });

    it('records the request', async () => {
      await api.getBottlesByCrate('id-1');
      expect(api.observations.recordRequest).toHaveBeenCalledWith(
        'http_response',
        `${CRATES_URL}/id-1/bottles`,
        {
          method: 'GET',
          path: `${CRATES_PATH}/${idFmt}/bottles`,
          code: '',
        },
      );
    });
  });

  describe('createBottleForCrate', () => {
    const body = {
      contents: {},
    };
    it('calls chevron with the url', async () => {
      await api.createBottleForCrate('id-1', body);

      expect(chevronMock.http).toHaveBeenCalledWith({
        url: `${CRATES_URL}/id-1/bottles`,
        method: 'POST',
        headers: JSON_HEADERS,
        body,
      });
    });

    it('records the request', async () => {
      await api.createBottleForCrate('id-1', body);
      expect(api.observations.recordRequest).toHaveBeenCalledWith(
        'http_response',
        `${CRATES_URL}/id-1/bottles`,
        {
          method: 'POST',
          path: `${CRATES_PATH}/${idFmt}/bottles`,
          code: '',
        },
      );
    });
  });
});
