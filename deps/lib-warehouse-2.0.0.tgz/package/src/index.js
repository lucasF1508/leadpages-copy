import { WarehouseApi } from './warehouse-api';

export default WarehouseApi;
