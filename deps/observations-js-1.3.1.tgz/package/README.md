observations-js
==============
JavaScript client library for interaction with the Observations API that tracks operational and behavior operational metrics.
Copyright (c) 2016 ALL RIGHTS RESERVED

# How to Use

ObservationsJS is available as a UMD package and can be included directly via script tag or as a CommonJS import. It makes available a `Observations` type that can be instantiated to track behavior and performance analytics about your application.

## Example

```bash
npm i @lp/observations-js --save
```

```javascript
var Observations = require('Observations');

var myObservations = new Observations({
  correlationId: 'ABCDEFG', // This is an identifier used to group up any observations
                            // sent from this instance. Typically, this will be a user,
                            // session, or pageview identifier. If not specified, a
                            // new UUID will be created for each instance.

  origin: 'my-module',      // Identification of your module for segmenting observation
                            // data. This prevents observations from leaking between
                            // modules or teams using Observations-JS

  version: '1.0.0'          // Version of your application reporting the observation.
                            // This is useful to track changes during releases.
});

// Observations can lookup the load time of an asset by URL and will record the
// milliseconds required to load the URL on the page.
myObservations.recordRequest('script-load', 'https://example.com/script.js');

// Observations of assets works for AJAX requests too.
myObservations.recordRequest('contact-load', 'https://api.com/contacts/ABC');

// You can also grab custom durations based on your code executions. `duration()`
// returns a function that you call to complete and record the duration timer.
var myActionDone = myObservations.recordDuration('button_clicks', {'button': 'submitOptIn');
DoAsyncAction().then(myActionDone);

// Or, you can always just specify everything by hand. Counter is useful for tallying
// up how many times a feature or option has been used.
myObservations.record('counter', 'user_feedback_submissions', '1', {'category': 'Split Testing', 'type' 'Suggestion'});

// Text is useful for logging interesting edge cases.
myObservations.record('text', 'urgent', 'some arbitrary text');
```

## Handling Async Observations

All observations are batched up and set asynchronously to the API. But sometimes, you'll
need to send something just as the user is leaving, and guarantee that the message
is sent to the server. In these cases, you can call `flush()` to make sure any
observations in queue have been sent.

```javascript
myObservations.record('counter', 'features_used_total', '1', {'feature': 'A'));
myObservations.record('counter', 'features_used_total', '1', {'feature': 'A'));
myObservations.record('counter', 'features_used_total', '1', {'feature': 'A');

myObservations.flush(function () {
  // all done, ready to go.
});
```

# Developer Setup

You must have **NODE** installed and available on your path. Then,
install these NPM packages globally:

    `sudo npm install --global gulp-cli karma-cli eslint protractor`

You will also need to make some additions to your `/etc/hosts` file so that we can simulate multiple origins for testing. Add this:

```
    127.0.0.1     api.dev
    127.0.0.1     foo.dev
```

## Building

The library and associated files can be built in either debug or release mode, as specified by the gulp task name.

The library should be built with the destination environment in mind, as specified by the `NODE_ENV` variable. The environments can be `LOCAL`, `STAGING`, or `PRODUCTION`. The values for these environments are kept in `config/environments.conf.js`.

Build a debug library for local
`gulp build:debug`

Build the compiled library for staging
`export NODE_ENV=STAGING && gulp build:release`

Build the compiled library for production
`export NODE_ENV=PRODUCTION && gulp build:release`

## Testing

The library can be tested quickly using a local Selenium server and Firefox browser. This is meant for rapid, iterative testing. For extensive pre-release testing across multiple browsers, the library is tested against the Saucelabs cloud.

To quickly test locally:
`gulp test:local` or `gulp test`

To thoroughly test against multiple browsers:
`gulp test:remote`

To setup a debug session for remote browser testing:
`gulp test:remote:debug`

## Deployment

The library is deployed to the internal NPM. Login with your Leadpages Test account:

```bash
npm login --registry http://npm.leadpages.io:8080 --scope @lp
```

Then publish with

```bash
npm run build
npm publish --scope @lp
```
