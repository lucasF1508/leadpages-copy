## 1.1.0 (2016-11-16)

Features:

  - Added `origin` setting to allow observations to be segmented by application, code, or module.

Bugfixes:

  - None

## 1.0.5 (2016-10-25)

Features:

  - Changed HTTP API to `api.leadpages.io`

Bugfixes:

  - None


## 1.0.2 (2016-08-23)

Features:

  - None

Bugfixes:

  - Renamed the package to `@lp/observations-js` for better installation from private NPM.


## 1.0.1 (2016-08-23)

Features:

  - Bad deployment, no changes.

Bugfixes:

  - None


## 1.0.0 (2016-08-23)

Features:

  - Initial release of ObservationsJS extracted from the CenterJS tracking library
  - Client wrapper for recording internal analytics against the Observation API
  - Helper functions for tracking asset load, duration, or arbitrary data
  - Batching and throttling of network requests

Bugfixes:

  - None
