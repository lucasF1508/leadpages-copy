# substring-matcher

A library for performing substring matching without using escaped regexes.
